const https = require('https');

const fetchPostData = () => {
    const url = 'https://jsonplaceholder.typicode.com/posts';

    return new Promise((resolve, reject) => {
        https.get(url, (response) => {
            let data = '';

            response.on('data', (chunk) => {
                data += chunk;
            });

            response.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (error) {
                    reject('Error parsing JSON from API 1');
                }
            });
        }).on('error', (error) => {
            reject(`Error with the request to API 1: ${error.message}`);
        });
    });
};

const fetchUserData = () => {
    const url = 'https://jsonplaceholder.typicode.com/users';

    return new Promise((resolve, reject) => {
        https.get(url, (response) => {
            let data = '';

            response.on('data', (chunk) => {
                data += chunk;
            });

            response.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (error) {
                    reject('Error parsing JSON from API 2');
                }
            });
        }).on('error', (error) => {
            reject(`Error with the request to API 2: ${error.message}`);
        });
    });
};

exports.handler = async (event, context) => {
    console.log("EVENT:\n" + JSON.stringify(event, null, 2))
    console.log("CONTEXT:\n" + JSON.stringify(context, null, 2))

    console.log("Start Time ==================: " + new Date().getTime())
    let diffTime = 0;
    const startTime = new Date().getTime();

    try {
        const [postData, userData] = await Promise.all([
            fetchPostData(),
            fetchUserData()
        ]);

        const endTime = new Date().getTime();
        diffTime = endTime - startTime;
        console.log("End Time ==================: " + new Date().getTime())
        console.log("Diff Time ==================: " + diffTime)
        console.log("Post Data ==================: " + JSON.stringify(postData))
        console.log("User Data ==================: " + JSON.stringify(userData))
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({error: error}),
        };
    }

    // return aws cloud watch log stream name
    return context.logStreamName;
};

